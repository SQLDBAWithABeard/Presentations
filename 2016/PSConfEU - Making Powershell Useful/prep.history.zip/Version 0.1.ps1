### prep 
if((Get-PSDrive OldSCripts -ErrorAction SilentlyContinue))
      {
        Remove-PSDrive OldScripts
      }
      if((Get-PSDrive Presentations -ErrorAction SilentlyContinue))
      {
        Remove-PSDrive Presentations
      }
if ($env:COMPUTERNAME -eq 'ROB-SURFACEBOOK')
    {
      New-PSDrive -Name OldScripts -PSProvider FileSystem -Root 'C:\Users\mrrob\OneDrive\Documents\Scripts\Powershell Scripts'
      New-PSDrive -Name Presentations -PSProvider FileSystem -Root 'C:\Users\mrrob\OneDrive\Documents\Presentations'

  if ((Get-Service MSSQLSERVER).status -eq 'Stopped')
    {Start-Service MSSQLSERVER}
}
if ($env:COMPUTERNAME -eq  'ROB-Laptop')
  {
        New-PSDrive -Name OldScripts -PSProvider FileSystem -Root 'E:\SkyDrive\Documents\Scripts\Powershell Scripts'
        New-PSDrive -Name Presentations -PSProvider FileSystem -Root 'E:\SkyDrive\Documents\Presentations'    
  }