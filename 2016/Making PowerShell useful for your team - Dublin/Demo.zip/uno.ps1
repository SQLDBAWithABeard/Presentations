﻿powershell -Commmand {Start-Demo -file 'Presentations:\Making PowerShell useful for your team - Dublin\dos.ps1'}
