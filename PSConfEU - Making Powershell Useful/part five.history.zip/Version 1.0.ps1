function New-GitPester
              {
                Write-Output "WOW"
              }
              #Check for Subnmenus
              $psTab = $psISE.CurrentPowerShellTab.addonsmenu
            if($psTab.Submenus)
              {
              #count them
              $I = $psTab.Submenus.Count - 1
              # loop through them and Remove the beard
              while($i -gt -1)
                  {
                    if($psTab.Submenus[$i].displayname.Contains('TheBeard'))
                      {
                        $null = $psTab.Submenus.remove($psTab.Submenus[$i])  
                        $i --
                      }    
                  }
              }
        ## Add in shortcut for new file with pester
        $TheBeard = $psTab.Submenus.Add('TheBeard',$null,$null)
        $null = $TheBeard.Submenus.Add('New Git File',{New-GitPester},'Ctrl+Alt+Shift+N')